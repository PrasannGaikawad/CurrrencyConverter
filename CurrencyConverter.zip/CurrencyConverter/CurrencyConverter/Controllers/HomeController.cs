using CurrencyConverter.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace CurrencyConverter.Controllers
{
    public class HomeController : Controller
    {
        private readonly List<ExchangeRate> rates = new List<ExchangeRate>()
        {
            new ExchangeRate(){ Currency = "USD [United States Dollar]" , Rate= 1m},
            new ExchangeRate(){Currency= "INR [Indian Rupee]", Rate= 83m},
            new ExchangeRate(){Currency= "EUR [Euro]", Rate= 0.85m},
            new ExchangeRate(){Currency= "GBP [British Pound Sterling]", Rate= 0.75m},
            new ExchangeRate(){Currency= "JPY [Japanese Yen]", Rate= 110m},
            new ExchangeRate(){Currency= "AUD [Australian Dollar]", Rate= 1.35m},
            new ExchangeRate(){Currency= "CAD [Canadian Dollar]", Rate= 1.25m},
            new ExchangeRate(){Currency= "CHF [Swiss Franc]", Rate= 0.92m},
            new ExchangeRate(){Currency= "CNY [Chinese Yuan]", Rate= 6.45m},
            new ExchangeRate(){Currency= "RUB [Russian Ruble]", Rate= 74m}
        };

        public IActionResult Convert(ExchangeRateView model)
        {
            // Debugging: Print out the selected currencies
            System.Diagnostics.Debug.WriteLine($"Converting from: {model.From}, to: {model.To}");

            var toRate = rates.FirstOrDefault(x => x.Currency == model.To)?.Rate;
            var fromRate = rates.FirstOrDefault(x => x.Currency == model.From)?.Rate;

            
            System.Diagnostics.Debug.WriteLine($"Rate from: {fromRate}, Rate to: {toRate}");

            if (toRate == null || fromRate == null)
            {
               
                model.FinalPrice = 0m;
                ModelState.AddModelError(string.Empty, "Selected currency not found.");
            }
            else
            {
                model.FinalPrice = model.Amount * (fromRate.Value / toRate.Value);
            }

            model.CurrencyRate = rates;

            return View("index", model);
        }

        public ActionResult Index()
        {
            var model = new ExchangeRateView
            {
                CurrencyRate = rates
            };
            return View(model);
        }
    }
}
