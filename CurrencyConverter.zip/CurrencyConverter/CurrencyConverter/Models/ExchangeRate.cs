﻿namespace CurrencyConverter.Models
{
    public class ExchangeRate
    {
        public string Currency { get; set; }
        public decimal Rate { get; set; }
    }
}