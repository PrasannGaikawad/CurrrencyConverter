﻿namespace CurrencyConverter.Models
{
    public class ExchangeRateView
    {
        public decimal Amount { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public decimal FinalPrice { get; set; }
        public List<ExchangeRate> CurrencyRate { get; set; }
    }
}